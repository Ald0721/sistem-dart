import 'package:flutter/material.dart';
import 'package:uprak/akun_page.dart';
import 'package:uprak/cart_page.dart';
import 'package:uprak/food_detail_page.dart';
import 'package:uprak/pengaturan_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lunch Food',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String selectedCategory = "Burger";
  final List<Map<String, dynamic>> cartItems =
      []; // List untuk item di keranjang

  final Map<String, List<Map<String, dynamic>>> menuData = {
    "Burger": [
      {
        "title": "Cheese Burger",
        "description": "Burger dengan keju leleh di atas daging.",
        "imagePath": "image/burger1.jpg",
        "price": 30000,
      },
      {
        "title": "Double Patty Burger",
        "description": "Burger dengan dua lapis daging yang juicy.",
        "imagePath": "image/burger2.jpg",
        "price": 40000,
      },
      {
        "title": "Chicken Burger",
        "description": "Burger ayam renyah dengan saus mayo.",
        "imagePath": "image/burger3.jpg",
        "price": 28000,
      },
      {
        "title": "Veggie Burger",
        "description": "Burger sehat dengan patty sayur segar.",
        "imagePath": "image/burger4.jpg",
        "price": 25000,
      },
      {
        "title": "BBQ Burger",
        "description": "Burger dengan saus BBQ smoky yang kaya rasa.",
        "imagePath": "image/burger5.jpg",
        "price": 35000,
      },
      {
        "title": "Spicy Burger",
        "description": "Burger pedas dengan jalapeno dan saus sambal.",
        "imagePath": "image/burger6.jpg",
        "price": 32000,
      },
    ],
    "Noodle": [
      {
        "title": "Spicy Ramen",
        "description": "Ramen pedas dengan kuah gurih dan topping lengkap.",
        "imagePath": "image/noodle1.jpg",
        "price": 25000,
      },
      {
        "title": "Chicken Noodles",
        "description": "Mie ayam dengan topping ayam kecap lezat.",
        "imagePath": "image/noodle2.jpg",
        "price": 20000,
      },
      {
        "title": "Seafood Udon",
        "description": "Udon dengan aneka seafood segar.",
        "imagePath": "image/noodle3.jpg",
        "price": 30000,
      },
      {
        "title": "Beef Pho",
        "description": "Mie kuah Vietnam dengan daging sapi empuk.",
        "imagePath": "image/noodle4.jpg",
        "price": 35000,
      },
      {
        "title": "Curry Noodles",
        "description": "Mie kuah kari dengan rasa pedas gurih.",
        "imagePath": "image/noodle5.jpg",
        "price": 32000,
      },
      {
        "title": "Vegetable Ramen",
        "description": "Ramen sehat dengan aneka sayuran segar.",
        "imagePath": "image/noodle6.jpg",
        "price": 30000,
      },
    ],
    "Desert": [
      {
        "title": "Chocolate Cake",
        "description": "Kue cokelat lembut dengan taburan cokelat.",
        "imagePath": "image/desert1.jpg",
        "price": 20000,
      },
      {
        "title": "Fruit Salad",
        "description": "Salad buah segar dengan saus yoghurt.",
        "imagePath": "image/desert2.jpg",
        "price": 15000,
      },
      {
        "title": "Tiramisu",
        "description": "Makanan pencuci mulut khas Italia dengan rasa kopi.",
        "imagePath": "image/desert3.jpg",
        "price": 25000,
      },
      {
        "title": "Pancake",
        "description": "Pancake lembut dengan sirup maple dan buah.",
        "imagePath": "image/desert4.jpg",
        "price": 18000,
      },
      {
        "title": "Brownie Sundae",
        "description": "Brownie dengan es krim vanila dan saus cokelat.",
        "imagePath": "image/desert5.jpg",
        "price": 22000,
      },
      {
        "title": "Oreo icebox cake",
        "description": "Kue keju lembut dengan saus stroberi.",
        "imagePath": "image/desert6.jpg",
        "price": 28000,
      },
    ],
    "Drink": [
      {
        "title": "Iced Coffee",
        "description": "Kopi dingin dengan es batu segar.",
        "imagePath": "image/drink1.jpg",
        "price": 10000,
      },
      {
        "title": "Lemonade",
        "description": "Minuman lemon segar dengan madu.",
        "imagePath": "image/drink2.jpg",
        "price": 12000,
      },
      {
        "title": "Smoothie Berry",
        "description": "Smoothie campuran aneka buah berry.",
        "imagePath": "image/drink3.jpg",
        "price": 15000,
      },
      {
        "title": "Mango Juice",
        "description": "Jus mangga segar tanpa gula tambahan.",
        "imagePath": "image/drink4.jpg",
        "price": 18000,
      },
      {
        "title": "Green Tea Latte",
        "description": "Minuman latte teh hijau yang creamy.",
        "imagePath": "image/drink5.jpg",
        "price": 20000,
      },
      {
        "title": "Coconut Water",
        "description": "Air kelapa segar untuk hidrasi alami.",
        "imagePath": "image/drink6.jpg",
        "price": 22000,
      },
    ],
  };

  void addToCart(Map<String, dynamic> item) {
    setState(() {
      cartItems.add(item);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: Builder(
          builder: (context) => IconButton(
            icon: Icon(Icons.menu, color: Colors.teal),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Membuka Drawer
            },
          ),
        ),
        title: Text(
          "Lunch Food",
          style: TextStyle(color: Colors.teal, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart, color: Colors.teal),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CartPage(),
                ),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.teal,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.person, color: Colors.teal, size: 40),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Welcome!",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  Text(
                    "ale",
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.teal),
              title: Text("Home"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.account_circle, color: Colors.teal),
              title: Text("Akun"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AkunPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.settings, color: Colors.teal),
              title: Text("Pengaturan"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PengaturanPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                DeliveryInfoCard(label: "20.000", subLabel: "Delivery Fee"),
                DeliveryInfoCard(label: "15-20 min", subLabel: "Delivery Time"),
              ],
            ),
          ),
          Container(
            color: Colors.grey.shade200,
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            height: 50,
            child: MediaQuery.of(context).size.width > 600
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      FoodCategoryTab(
                        label: "Burger",
                        isSelected: selectedCategory == "Burger",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Burger";
                          });
                        },
                      ),
                      FoodCategoryTab(
                        label: "Noodle",
                        isSelected: selectedCategory == "Noodle",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Noodle";
                          });
                        },
                      ),
                      FoodCategoryTab(
                        label: "Desert",
                        isSelected: selectedCategory == "Desert",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Desert";
                          });
                        },
                      ),
                      FoodCategoryTab(
                        label: "Drink",
                        isSelected: selectedCategory == "Drink",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Drink";
                          });
                        },
                      ),
                    ],
                  )
                : ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      FoodCategoryTab(
                        label: "Burger",
                        isSelected: selectedCategory == "Burger",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Burger";
                          });
                        },
                      ),
                      FoodCategoryTab(
                        label: "Noodle",
                        isSelected: selectedCategory == "Noodle",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Noodle";
                          });
                        },
                      ),
                      FoodCategoryTab(
                        label: "Desert",
                        isSelected: selectedCategory == "Desert",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Desert";
                          });
                        },
                      ),
                      FoodCategoryTab(
                        label: "Drink",
                        isSelected: selectedCategory == "Drink",
                        onTap: () {
                          setState(() {
                            selectedCategory = "Drink";
                          });
                        },
                      ),
                    ],
                  ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: menuData[selectedCategory]!.length,
              itemBuilder: (context, index) {
                final item = menuData[selectedCategory]![index];
                return FoodItemCard(
                  title: item["title"],
                  description: item["description"],
                  imagePath: item["imagePath"],
                  price: item["price"],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class DeliveryInfoCard extends StatelessWidget {
  final String label;
  final String subLabel;

  const DeliveryInfoCard({required this.label, required this.subLabel});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.teal,
                  fontSize: 16),
            ),
            Text(
              subLabel,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class FoodCategoryTab extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const FoodCategoryTab({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Center(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            decoration: BoxDecoration(
              color: isSelected
                  ? Colors.teal.withOpacity(0.2)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.teal : Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class FoodItemCard extends StatelessWidget {
  final String title;
  final String description;
  final String imagePath;
  final int price;

  const FoodItemCard({
    required this.title,
    required this.description,
    required this.imagePath,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => FoodDetailPage(
              title: title,
              description: description,
              imagePath: imagePath,
              price: price,
            ),
          ),
        );
      },
      child: Card(
        child: ListTile(
          leading: Image.asset(imagePath, width: 60, fit: BoxFit.cover),
          title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(description),
          trailing: Text("Rp $price"),
        ),
      ),
    );
  }
}
