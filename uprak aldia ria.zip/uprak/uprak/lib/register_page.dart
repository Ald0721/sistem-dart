import 'package:flutter/material.dart';

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Top Image
              Container(
                width: double.infinity,
                height: 230, // Height of the top image
                child: Image.asset(
                  'image/makan.jpeg', // Replace with your image path
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(height: 20),
              // Title Text
              Text(
                "Let's create an account for you",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              // Email Input
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0),
                child: TextField(
                  decoration: InputDecoration(
                    labelText: 'Email',
                    filled: true,
                    fillColor: Colors.teal.shade50,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 15),
              // Password Input
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0),
                child: TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    filled: true,
                    fillColor: Colors.teal.shade50,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 15),
              // Confirm Password Input
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0),
                child: TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Confirm password',
                    filled: true,
                    fillColor: Colors.teal.shade50,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 15),
              // Remember Me Checkbox
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0),
                child: Row(
                  children: [
                    Checkbox(
                      value: false,
                      onChanged: (value) {
                        // Add checkbox logic
                      },
                    ),
                    Text("Remember me"),
                  ],
                ),
              ),
              SizedBox(height: 15),
              // Sign Up Button
              ElevatedButton(
                onPressed: () {
                  // Add sign-up functionality
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  minimumSize: Size(200, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: Text('Sign up'),
              ),
              SizedBox(height: 20),
              // Login With Google and Facebook
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Sign Up With"),
                  SizedBox(width: 10),
                  // Google Icon
                  IconButton(
                    iconSize: 40, // Standard size for the icon
                    icon: ClipOval(
                      child: Image.asset(
                        'image/google.png', // Replace with your Google logo path
                        width: 30, // Set the desired width
                        height: 30, // Set the desired height
                        fit: BoxFit.cover,
                      ),
                    ),
                    onPressed: () {
                      // Add Google login functionality
                    },
                  ),
                  SizedBox(width: 20), // Space between icons
                  // Facebook Icon
                  IconButton(
                    iconSize: 40, // Standard size for the icon
                    icon: ClipOval(
                      child: Image.asset(
                        'image/facebook.jpeg', // Replace with your Facebook logo path
                        width: 30, // Set the desired width
                        height: 30, // Set the desired height
                        fit: BoxFit.cover,
                      ),
                    ),
                    onPressed: () {
                      // Add Facebook login functionality
                    },
                  ),
                ],
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
