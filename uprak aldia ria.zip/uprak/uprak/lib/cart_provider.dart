import 'package:flutter/material.dart';

class CartProvider with ChangeNotifier {
  List<Map<String, dynamic>> _cartItems = [];

  List<Map<String, dynamic>> get cartItems => _cartItems;

  void addToCart(Map<String, dynamic> item) {
    // Periksa apakah item dengan ID unik sudah ada di keranjang
    final index = _cartItems.indexWhere((i) => i["id"] == item["id"]);
    if (index == -1) {
      _cartItems.add(
          {...item, "quantity": 1}); // Tambahkan item baru dengan kuantitas 1
    } else {
      _cartItems[index]["quantity"] +=
          1; // Tambah kuantitas jika item sudah ada
    }
    notifyListeners();
  }

  void removeFromCart(Map<String, dynamic> item) {
    _cartItems.removeWhere((i) => i["id"] == item["id"]);
    notifyListeners();
  }

  void updateItemQuantity(Map<String, dynamic> item, int newQuantity) {
    final index = _cartItems.indexWhere((i) => i["id"] == item["id"]);
    if (index != -1) {
      if (newQuantity <= 0) {
        _cartItems.removeAt(index); // Hapus item jika kuantitas <= 0
      } else {
        _cartItems[index]["quantity"] = newQuantity;
      }
      notifyListeners();
    }
  }

  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }
}
