import 'package:flutter/material.dart';
import 'package:uprak/home_page.dart';
import 'package:uprak/login_page.dart';
import 'package:uprak/pengaturan_page.dart';

class AkunPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Akun"),
        backgroundColor: Colors.teal,
        elevation: 0,
        leading: Builder(
          builder: (context) => IconButton(
            icon: Icon(Icons.menu, color: Colors.white),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Membuka Drawer
            },
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.teal,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.person, color: Colors.teal, size: 50),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Hello, Ale!",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  Text(
                    "ale@gmail.com",
                    style: TextStyle(color: Colors.white70, fontSize: 10),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.teal),
              title: Text("Home"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.account_circle, color: Colors.teal),
              title: Text("Akun"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AkunPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.settings, color: Colors.teal),
              title: Text("Pengaturan"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PengaturanPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Profile
              Center(
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.teal.shade100,
                      child: Icon(
                        Icons.person,
                        color: Colors.teal,
                        size: 60,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Ale",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                      ),
                    ),
                    Text(
                      "ale@example.com",
                      style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 30),

              // Actions Section
              Text(
                "Akun Saya",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal,
                ),
              ),
              SizedBox(height: 10),
              ListTile(
                leading: Icon(Icons.edit, color: Colors.teal),
                title: Text("Edit Profil"),
                subtitle: Text("Perbarui nama, email, atau foto profil"),
                onTap: () {
                  // Tambahkan navigasi atau fungsi ke halaman edit profil
                  print("Navigasi ke halaman Edit Profil");
                },
              ),
              Divider(),
              ListTile(
                leading: Icon(Icons.lock, color: Colors.teal),
                title: Text("Ubah Kata Sandi"),
                subtitle: Text("Perbarui kata sandi akun Anda"),
                onTap: () {
                  // Tambahkan navigasi atau fungsi ke halaman ubah kata sandi
                  print("Navigasi ke halaman Ubah Kata Sandi");
                },
              ),
              Divider(),
              ListTile(
                leading: Icon(Icons.history, color: Colors.teal),
                title: Text("Riwayat Pembelian"),
                subtitle: Text("Lihat transaksi yang sudah Anda lakukan"),
                onTap: () {
                  // Tambahkan navigasi ke halaman riwayat pembelian
                  print("Navigasi ke halaman Riwayat Pembelian");
                },
              ),
              Divider(),

              // Logout Section
              SizedBox(height: 30),
              Center(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    minimumSize: Size(double.infinity, 50),
                  ),
                  icon: Icon(Icons.logout, color: Colors.white),
                  label: Text(
                    "Logout",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => LoginPage()),
                    );
                    print("Logout ditekan");
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("Anda telah logout"),
                    ));
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
