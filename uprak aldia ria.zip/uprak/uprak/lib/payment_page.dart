import 'package:flutter/material.dart';

class PaymentPage extends StatefulWidget {
  final double totalPrice;
  final VoidCallback onPaymentSuccess;

  PaymentPage({required this.totalPrice, required this.onPaymentSuccess});

  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  final _nameController = TextEditingController();
  final _cardNumberController = TextEditingController();
  final _expiryDateController = TextEditingController();
  final _cvvController = TextEditingController();

  void _validateAndPay() {
    final name = _nameController.text.trim();
    final cardNumber = _cardNumberController.text.trim();
    final expiryDate = _expiryDateController.text.trim();
    final cvv = _cvvController.text.trim();

    if (name.isEmpty ||
        cardNumber.isEmpty ||
        expiryDate.isEmpty ||
        cvv.isEmpty) {
      // Tampilkan pesan kesalahan jika ada bidang yang kosong
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Payment Failed"),
          content:
              Text("All fields must be filled in to proceed with payment."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Tutup dialog
              },
              child: Text("OK"),
            ),
          ],
        ),
      );
    } else {
      // Jika semua bidang terisi, proses pembayaran
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Payment Successful"),
          content: Text("You have paid Rp ${widget.totalPrice}."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Tutup dialog
                Navigator.pop(context); // Kembali ke halaman sebelumnya
                widget.onPaymentSuccess(); // Panggil fungsi clearCart
              },
              child: Text("OK"),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Checkout"),
        backgroundColor: Colors.cyan,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Card image
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(vertical: 20),
              child: Image.asset(
                "image/credit.jpg", // Ganti dengan path gambar kartu kredit
                height: 150,
                fit: BoxFit.cover,
              ),
            ),
            // Name field
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: "Name",
                hintText: "Enter cardholder name",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 15),
            // Card number field
            TextField(
              controller: _cardNumberController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Card Number",
                hintText: "Enter card number",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 15),
            // Expiry date and CVV
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _expiryDateController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "MM/YY",
                      hintText: "12/30",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _cvvController,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: "CVV",
                      hintText: "***",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            // Pay Now button
            ElevatedButton(
              onPressed: _validateAndPay,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.cyan,
                padding: EdgeInsets.symmetric(vertical: 15),
              ),
              child: Text(
                "Pay Now",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
