import 'package:flutter/material.dart';
import 'package:uprak/akun_page.dart';
import 'package:uprak/home_page.dart';
import 'package:uprak/login_page.dart';

class PengaturanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pengaturan"),
        backgroundColor: Colors.teal,
        elevation: 0,
        leading: Builder(
          builder: (context) => IconButton(
            icon: Icon(Icons.menu, color: Colors.white),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Membuka Drawer
            },
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.teal,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.person, color: Colors.teal, size: 40),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Welcome!",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  Text(
                    "ale",
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.teal),
              title: Text("Home"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.account_circle, color: Colors.teal),
              title: Text("Akun"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AkunPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.settings, color: Colors.teal),
              title: Text("Pengaturan"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PengaturanPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          // Bagian Akun
          ListTile(
            leading: Icon(Icons.person, color: Colors.teal),
            title: Text("Akun"),
            subtitle: Text("Kelola informasi akun Anda"),
            onTap: () {
              // Tambahkan navigasi ke halaman akun
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AkunPage()),
              );
            },
          ),
          Divider(),

          // Bagian Notifikasi
          ListTile(
            leading: Icon(Icons.notifications, color: Colors.teal),
            title: Text("Notifikasi"),
            subtitle: Text("Pengaturan notifikasi aplikasi"),
            onTap: () {
              // Navigasi ke halaman pengaturan notifikasi
            },
          ),
          Divider(),

          // Bagian Privasi
          ListTile(
            leading: Icon(Icons.lock, color: Colors.teal),
            title: Text("Privasi"),
            subtitle: Text("Pengaturan privasi dan keamanan"),
            onTap: () {
              // Navigasi ke halaman pengaturan privasi
            },
          ),
          Divider(),

          // Bagian Bahasa
          ListTile(
            leading: Icon(Icons.language, color: Colors.teal),
            title: Text("Bahasa"),
            subtitle: Text("Ubah bahasa aplikasi"),
            onTap: () {
              // Navigasi ke halaman pengaturan bahasa
            },
          ),
          Divider(),

          // Bagian Tema
          ListTile(
            leading: Icon(Icons.palette, color: Colors.teal),
            title: Text("Tema"),
            subtitle: Text("Atur tema terang atau gelap"),
            onTap: () {
              // Navigasi ke halaman pengaturan tema
            },
          ),
          Divider(),

          // Bagian Bantuan
          ListTile(
            leading: Icon(Icons.help, color: Colors.teal),
            title: Text("Bantuan"),
            subtitle: Text("FAQ dan layanan pelanggan"),
            onTap: () {
              // Navigasi ke halaman bantuan
            },
          ),
          Divider(),

          // Bagian Tentang
          ListTile(
            leading: Icon(Icons.info, color: Colors.teal),
            title: Text("Tentang Aplikasi"),
            subtitle: Text("Informasi versi dan detail aplikasi"),
            onTap: () {
              // Navigasi ke halaman tentang aplikasi
            },
          ),
          Divider(),

          // Logout
          ListTile(
            leading: Icon(Icons.logout, color: Colors.red),
            title: Text("Keluar"),
            subtitle: Text("Logout dari akun Anda"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LoginPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}
