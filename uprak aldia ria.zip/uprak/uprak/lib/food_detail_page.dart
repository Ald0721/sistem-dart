import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_provider.dart';

class FoodDetailPage extends StatefulWidget {
  final String title;
  final String description;
  final String imagePath;
  final int price;

  const FoodDetailPage({
    required this.title,
    required this.description,
    required this.imagePath,
    required this.price,
  });

  @override
  _FoodDetailPageState createState() => _FoodDetailPageState();
}

class _FoodDetailPageState extends State<FoodDetailPage> {
  // Daftar topping dan status pilihan
  bool cheese = false;
  bool bacon = false;
  bool lettuce = false;

  // Menghitung total harga
  int get totalPrice {
    int total = widget.price;
    if (cheese) total += 5000; // Topping Cheese
    if (bacon) total += 7000; // Topping Bacon
    if (lettuce) total += 3000; // Topping Lettuce
    return total;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              widget.imagePath,
              width: double.infinity,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.title,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "Rp $totalPrice",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    widget.description,
                    style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                  ),
                  SizedBox(height: 20),

                  // Pilihan topping
                  Text(
                    "Pilih Topping (Optional):",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                  ),
                  SizedBox(height: 10),
                  Column(
                    children: [
                      CheckboxListTile(
                        title: Text("Cheese (Rp 5000)"),
                        value: cheese,
                        onChanged: (bool? value) {
                          setState(() {
                            cheese = value!;
                          });
                        },
                      ),
                      CheckboxListTile(
                        title: Text("Bacon (Rp 7000)"),
                        value: bacon,
                        onChanged: (bool? value) {
                          setState(() {
                            bacon = value!;
                          });
                        },
                      ),
                      CheckboxListTile(
                        title: Text("Lettuce (Rp 3000)"),
                        value: lettuce,
                        onChanged: (bool? value) {
                          setState(() {
                            lettuce = value!;
                          });
                        },
                      ),
                    ],
                  ),

                  SizedBox(height: 20),

                  // Tombol Add to Cart
                  // Tombol Add to Cart
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        final item = {
                          "id":
                              '${widget.title}_${DateTime.now().millisecondsSinceEpoch}', // ID unik
                          "title": widget.title,
                          "price":
                              totalPrice, // Gunakan totalPrice yang sudah dihitung
                          "imagePath": widget.imagePath,
                          "toppings": {
                            "Cheese": cheese,
                            "Bacon": bacon,
                            "Lettuce": lettuce,
                          },
                        };

                        // Menambahkan item ke keranjang
                        Provider.of<CartProvider>(context, listen: false)
                            .addToCart(item);

                        // Tampilkan notifikasi
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(
                              '${widget.title} (Rp $totalPrice) telah ditambahkan ke keranjang'),
                        ));
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.cyan,
                        minimumSize: Size(200, 50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text("Add to cart"),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
